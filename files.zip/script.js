/**
 * CRSPY AR Glasses — script.js
 * Interactive AR demo powered by Three.js.
 * Handles: scene lifecycle, cube management, controls, webcam,
 *          device orientation, cursor, scroll reveals, toasts, nav.
 *
 * Author : CRSPY Interactive v1.0
 */

/* =============================================================
   1. STRICT MODE & TOP-LEVEL GUARDS
============================================================= */
'use strict';

// Ensure Three.js is present (loaded via CDN in HTML)
const THREE_AVAILABLE = typeof THREE !== 'undefined';

/* =============================================================
   2. DOM REFERENCES
   Grab every element we need, with safe null guards.
============================================================= */
const DOM = {
  body:              document.body,
  header:            document.getElementById('siteHeader'),
  cursorDot:         document.getElementById('cursorDot'),
  cursorRing:        document.getElementById('cursorRing'),
  hamburgerBtn:      document.getElementById('hamburgerBtn'),
  mobileMenu:        document.getElementById('mobileMenu'),
  mobileNavLinks:    document.querySelectorAll('.mobile-nav-link'),

  // Demo
  startDemoBtn:      document.getElementById('startDemoBtn'),
  startDemoBtn2:     document.getElementById('startDemoBtn2'),
  demoIdle:          document.getElementById('demoIdle'),
  arViewport:        document.getElementById('arViewport'),
  xrContainer:       document.getElementById('xrContainer'),
  webcamOverlay:     document.getElementById('webcamOverlay'),
  webcamFeed:        document.getElementById('webcamFeed'),

  // HUD
  hudStatus:         document.getElementById('hudStatus'),
  hudFps:            document.getElementById('hudFps'),
  hudCoords:         document.getElementById('hudCoords'),
  hudCubeCount:      document.getElementById('hudCubeCount'),

  // Sidebar
  demoSidebar:       document.getElementById('demoSidebar'),
  sidebarClose:      document.getElementById('sidebarClose'),
  toggleSidebarBtn:  document.getElementById('toggleSidebarBtn'),
  applySceneBtn:     document.getElementById('applySceneBtn'),
  resetSceneBtn:     document.getElementById('resetSceneBtn'),

  // Sliders
  sliderCubeCount:   document.getElementById('sliderCubeCount'),
  sliderSpeed:       document.getElementById('sliderSpeed'),
  sliderGlow:        document.getElementById('sliderGlow'),
  sliderRadius:      document.getElementById('sliderRadius'),

  // Slider fill tracks
  trackCubeCount:    document.getElementById('trackCubeCount'),
  trackSpeed:        document.getElementById('trackSpeed'),
  trackGlow:         document.getElementById('trackGlow'),
  trackRadius:       document.getElementById('trackRadius'),

  // Slider value labels
  valCubeCount:      document.getElementById('valCubeCount'),
  valSpeed:          document.getElementById('valSpeed'),
  valGlow:           document.getElementById('valGlow'),
  valRadius:         document.getElementById('valRadius'),

  // Toggles
  toggleLabels:      document.getElementById('toggleLabels'),
  toggleWireframe:   document.getElementById('toggleWireframe'),
  toggleOrbit:       document.getElementById('toggleOrbit'),
  toggleWebcam:      document.getElementById('toggleWebcam'),

  // Palette buttons
  paletteBtns:       document.querySelectorAll('.palette-btn'),

  // Instructions
  instructionsToggle:document.getElementById('instructionsToggle'),
  instructionsBody:  document.getElementById('instructionsBody'),

  // Toast container
  toastContainer:    document.getElementById('toastContainer'),

  // Reveal elements
  revealEls:         document.querySelectorAll('.reveal'),

  // Nav links
  navLinks:          document.querySelectorAll('.nav-link'),
};

/* =============================================================
   3. GLOBAL APPLICATION STATE
============================================================= */
const STATE = {
  demoActive:        false,    // Is the 3D demo running?
  demoInitialised:   false,    // Has THREE scene been built?
  sidebarOpen:       true,     // Desktop sidebar visibility
  instructionsOpen:  true,     // Instructions panel open
  webcamActive:      false,    // Webcam feed running
  palette:           'neon',   // Active colour theme

  // Scene settings (mirrored from sliders)
  cubeCount:         6,
  rotationSpeed:     1.0,      // multiplier (0–3)
  glowIntensity:     0.5,      // 0–1
  spreadRadius:      4.0,

  // Rendering
  fps:               0,
  frameCount:        0,
  lastFpsTime:       0,

  // Interaction
  mouseX:            0,
  mouseY:            0,
  hoveredCube:       null,
  selectedCube:      null,

  // Device orientation
  deviceBeta:        0,
  deviceGamma:       0,
};

/* =============================================================
   4. THREE.JS SCENE OBJECTS
============================================================= */
const SCENE = {
  renderer:  null,
  scene:     null,
  camera:    null,
  cubes:     [],           // Array of { mesh, label, basePos, speed }
  raycaster: null,
  pointer:   new (THREE_AVAILABLE ? THREE.Vector2 : Object)(),
  clock:     null,
  animId:    null,
  orbitAngle: 0,           // auto-orbit accumulator
};

/* =============================================================
   5. COLOUR PALETTE MAP
   Maps palette names to hex accent colours used in THREE
============================================================= */
const PALETTE_COLORS = {
  neon:   0x00f5ff,
  plasma: 0xbf5fff,
  ember:  0xff6b35,
  matrix: 0x39ff14,
};

/* =============================================================
   6. UTILITY HELPERS
============================================================= */

/**
 * Clamp a value between min and max.
 * @param {number} val
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
const clamp = (val, min, max) => Math.min(Math.max(val, min), max);

/**
 * Linear interpolation.
 * @param {number} a  Start
 * @param {number} b  End
 * @param {number} t  Factor 0–1
 * @returns {number}
 */
const lerp = (a, b, t) => a + (b - a) * t;

/**
 * Random float between two values.
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
const randFloat = (min, max) => min + Math.random() * (max - min);

/**
 * Debounce a function.
 * @param {Function} fn
 * @param {number} delay  ms
 * @returns {Function}
 */
const debounce = (fn, delay) => {
  let id;
  return (...args) => {
    clearTimeout(id);
    id = setTimeout(() => fn(...args), delay);
  };
};

/**
 * Convert a hex colour to a CSS rgb() string.
 * @param {number} hex  e.g. 0x00f5ff
 * @returns {string}    e.g. "0,245,255"
 */
const hexToRgb = (hex) => {
  const r = (hex >> 16) & 255;
  const g = (hex >> 8)  & 255;
  const b =  hex        & 255;
  return `${r},${g},${b}`;
};

/* =============================================================
   7. TOAST NOTIFICATION SYSTEM
============================================================= */

/**
 * Show a toast notification.
 * @param {string} message   Text to display
 * @param {'info'|'success'|'warn'} type
 * @param {number} duration  ms before auto-dismiss (0 = manual only)
 */
function showToast(message, type = 'info', duration = 3500) {
  if (!DOM.toastContainer) return;

  const icons = { info: '◈', success: '✓', warn: '!' };

  // Build toast element
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.setAttribute('role', 'status');
  toast.innerHTML = `
    <div class="toast-icon ${type}" aria-hidden="true">${icons[type] || '◈'}</div>
    <span class="toast-msg">${message}</span>
    <button class="toast-close" aria-label="Dismiss notification">✕</button>
  `;

  // Close button
  toast.querySelector('.toast-close').addEventListener('click', () => dismissToast(toast));

  DOM.toastContainer.appendChild(toast);

  // Trigger entrance animation on next frame
  requestAnimationFrame(() => {
    requestAnimationFrame(() => toast.classList.add('show'));
  });

  // Auto-dismiss
  if (duration > 0) {
    setTimeout(() => dismissToast(toast), duration);
  }
}

/**
 * Animate and remove a toast element.
 * @param {HTMLElement} toast
 */
function dismissToast(toast) {
  if (!toast || !toast.parentNode) return;
  toast.classList.remove('show');
  toast.classList.add('hiding');
  toast.addEventListener('transitionend', () => toast.remove(), { once: true });
}

/* =============================================================
   8. CUSTOM CURSOR
============================================================= */
(function initCursor() {
  if (!DOM.cursorDot || !DOM.cursorRing) return;

  // Check if primary pointer is mouse (not touch-only)
  if (!window.matchMedia('(hover: hover)').matches) return;

  let ringX = 0, ringY = 0;
  let dotX  = 0, dotY  = 0;
  let raf;

  const onMove = (e) => {
    dotX = e.clientX;
    dotY = e.clientY;
  };
  document.addEventListener('mousemove', onMove, { passive: true });

  const render = () => {
    // Dot follows cursor exactly
    DOM.cursorDot.style.left  = dotX + 'px';
    DOM.cursorDot.style.top   = dotY + 'px';

    // Ring lags behind (eased)
    ringX = lerp(ringX, dotX, 0.14);
    ringY = lerp(ringY, dotY, 0.14);
    DOM.cursorRing.style.left = ringX + 'px';
    DOM.cursorRing.style.top  = ringY + 'px';

    raf = requestAnimationFrame(render);
  };
  raf = requestAnimationFrame(render);

  // Hide cursor when leaving window
  document.addEventListener('mouseleave', () => {
    DOM.cursorDot.style.opacity  = '0';
    DOM.cursorRing.style.opacity = '0';
  });
  document.addEventListener('mouseenter', () => {
    DOM.cursorDot.style.opacity  = '1';
    DOM.cursorRing.style.opacity = '0.6';
  });
})();

/* =============================================================
   9. SCROLL BEHAVIOURS
   - Header scroll class
   - Active nav link highlighting
   - Reveal-on-scroll
============================================================= */

/**
 * Update header appearance on scroll.
 */
function onScroll() {
  const scrollY = window.scrollY;

  // Sticky header effect
  if (DOM.header) {
    DOM.header.classList.toggle('scrolled', scrollY > 60);
  }

  // Active nav highlight
  const sections = document.querySelectorAll('section[id]');
  let current = '';
  sections.forEach(sec => {
    if (sec.offsetTop - 100 <= scrollY) current = sec.id;
  });
  DOM.navLinks.forEach(link => {
    const href = link.getAttribute('href')?.slice(1);
    link.classList.toggle('active', href === current);
  });

  // Reveal elements
  DOM.revealEls.forEach(el => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight * 0.9) el.classList.add('visible');
  });
}

window.addEventListener('scroll', onScroll, { passive: true });
onScroll(); // Run once on load

// Add reveal class to sections we want to animate in
document.querySelectorAll(
  '.feature-card, .app-cube, .spec-item, .section-header'
).forEach((el, i) => {
  el.classList.add('reveal');
  el.classList.add(`reveal-delay-${Math.min((i % 5) + 1, 5)}`);
});

/* =============================================================
   10. MOBILE NAVIGATION
============================================================= */
(function initMobileNav() {
  if (!DOM.hamburgerBtn || !DOM.mobileMenu) return;

  DOM.hamburgerBtn.addEventListener('click', () => {
    const expanded = DOM.hamburgerBtn.getAttribute('aria-expanded') === 'true';
    DOM.hamburgerBtn.setAttribute('aria-expanded', String(!expanded));
    DOM.mobileMenu.classList.toggle('open', !expanded);
    DOM.mobileMenu.setAttribute('aria-hidden', String(expanded));
  });

  // Close on link click
  DOM.mobileNavLinks.forEach(link => {
    link.addEventListener('click', () => {
      DOM.hamburgerBtn.setAttribute('aria-expanded', 'false');
      DOM.mobileMenu.classList.remove('open');
      DOM.mobileMenu.setAttribute('aria-hidden', 'true');
    });
  });
})();

/* =============================================================
   11. SLIDER CONTROLS
   Each slider updates STATE and the visual fill + value label.
============================================================= */

/**
 * Sync a slider's fill track based on current value.
 * @param {HTMLInputElement} slider
 * @param {HTMLElement} track
 */
function updateSliderFill(slider, track) {
  if (!slider || !track) return;
  const pct = ((slider.value - slider.min) / (slider.max - slider.min)) * 100;
  track.style.width = pct + '%';
}

/**
 * Initialise all sliders with live value feedback.
 */
function initSliders() {

  // Helper: wire up one slider
  const wire = (slider, track, label, formatter, stateKey) => {
    if (!slider) return;

    // Set initial fill
    updateSliderFill(slider, track);

    slider.addEventListener('input', () => {
      updateSliderFill(slider, track);
      const formatted = formatter(parseFloat(slider.value));
      if (label) label.textContent = formatted;
      if (stateKey) STATE[stateKey] = parseFloat(slider.value);

      // Live-update scene if running
      if (STATE.demoActive) liveUpdateScene(stateKey, parseFloat(slider.value));
    });
  };

  wire(
    DOM.sliderCubeCount,
    DOM.trackCubeCount,
    DOM.valCubeCount,
    v => Math.round(v),
    'cubeCount'
  );

  wire(
    DOM.sliderSpeed,
    DOM.trackSpeed,
    DOM.valSpeed,
    v => (v / 10).toFixed(1) + '×',
    'rotationSpeed'
  );

  wire(
    DOM.sliderGlow,
    DOM.trackGlow,
    DOM.valGlow,
    v => Math.round(v) + '%',
    'glowIntensity'
  );

  wire(
    DOM.sliderRadius,
    DOM.trackRadius,
    DOM.valRadius,
    v => v.toFixed(1),
    'spreadRadius'
  );
}

initSliders();

/* =============================================================
   12. TOGGLE CONTROLS
============================================================= */
(function initToggles() {

  // Labels toggle
  if (DOM.toggleLabels) {
    DOM.toggleLabels.addEventListener('change', () => {
      const show = DOM.toggleLabels.checked;
      SCENE.cubes.forEach(({ label }) => {
        if (label) label.style.display = show ? 'block' : 'none';
      });
    });
  }

  // Wireframe toggle
  if (DOM.toggleWireframe) {
    DOM.toggleWireframe.addEventListener('change', () => {
      const wire = DOM.toggleWireframe.checked;
      SCENE.cubes.forEach(({ mesh }) => {
        if (mesh && mesh.material) {
          mesh.material.wireframe = wire;
        }
      });
      showToast(wire ? 'Wireframe mode enabled' : 'Wireframe mode disabled', 'info', 2000);
    });
  }

  // Auto-orbit toggle
  if (DOM.toggleOrbit) {
    DOM.toggleOrbit.addEventListener('change', () => {
      // STATE is read in the animation loop
    });
  }

  // Webcam toggle
  if (DOM.toggleWebcam) {
    DOM.toggleWebcam.addEventListener('change', () => {
      if (DOM.toggleWebcam.checked) {
        startWebcam();
      } else {
        stopWebcam();
      }
    });
  }
})();

/* =============================================================
   13. WEBCAM
============================================================= */

/**
 * Request camera access and pipe it to the video element.
 */
async function startWebcam() {
  if (!navigator.mediaDevices?.getUserMedia) {
    showToast('Webcam not available in this browser', 'warn');
    if (DOM.toggleWebcam) DOM.toggleWebcam.checked = false;
    return;
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false
    });
    if (!DOM.webcamFeed) return;
    DOM.webcamFeed.srcObject = stream;
    DOM.webcamFeed.style.display = 'block';
    STATE.webcamActive = true;
    showToast('Webcam activated — live feed running', 'success');
  } catch (err) {
    console.warn('[CRSPY] Webcam access denied:', err.message);
    showToast('Camera access denied. Check browser permissions.', 'warn');
    if (DOM.toggleWebcam) DOM.toggleWebcam.checked = false;
  }
}

/**
 * Stop the webcam stream and hide the video element.
 */
function stopWebcam() {
  if (!DOM.webcamFeed) return;
  const stream = DOM.webcamFeed.srcObject;
  if (stream) {
    stream.getTracks().forEach(track => track.stop());
    DOM.webcamFeed.srcObject = null;
  }
  DOM.webcamFeed.style.display = 'none';
  STATE.webcamActive = false;
  showToast('Webcam feed stopped', 'info', 2000);
}

/* =============================================================
   14. PALETTE SWITCHER
============================================================= */
(function initPalette() {
  DOM.paletteBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const palette = btn.dataset.palette;
      if (!palette || palette === STATE.palette) return;

      // Update active class
      DOM.paletteBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      // Remove all palette classes from body, add new one
      DOM.body.classList.remove('palette-neon', 'palette-plasma', 'palette-ember', 'palette-matrix');
      DOM.body.classList.add(`palette-${palette}`);

      STATE.palette = palette;

      // Update Three.js materials if scene is active
      if (STATE.demoActive) updateCubePalette();

      showToast(`Theme changed to ${palette.charAt(0).toUpperCase() + palette.slice(1)}`, 'info', 2000);
    });
  });
})();

/* =============================================================
   15. SIDEBAR TOGGLE
============================================================= */
(function initSidebar() {
  // Toggle sidebar visibility (desktop)
  if (DOM.toggleSidebarBtn) {
    DOM.toggleSidebarBtn.addEventListener('click', () => {
      STATE.sidebarOpen = !STATE.sidebarOpen;
      if (DOM.demoSidebar) {
        DOM.demoSidebar.classList.toggle('collapsed', !STATE.sidebarOpen);
        DOM.demoSidebar.classList.toggle('mobile-open', STATE.sidebarOpen);
      }
      DOM.toggleSidebarBtn.setAttribute('aria-expanded', String(STATE.sidebarOpen));
    });
  }

  // Close button (mobile)
  if (DOM.sidebarClose) {
    DOM.sidebarClose.addEventListener('click', () => {
      STATE.sidebarOpen = false;
      if (DOM.demoSidebar) DOM.demoSidebar.classList.remove('mobile-open');
    });
  }
})();

/* =============================================================
   16. INSTRUCTIONS PANEL
============================================================= */
(function initInstructions() {
  if (!DOM.instructionsToggle || !DOM.instructionsBody) return;

  DOM.instructionsToggle.addEventListener('click', () => {
    STATE.instructionsOpen = !STATE.instructionsOpen;
    DOM.instructionsBody.classList.toggle('collapsed', !STATE.instructionsOpen);
    DOM.instructionsToggle.textContent = STATE.instructionsOpen ? '−' : '+';
    DOM.instructionsToggle.setAttribute('aria-expanded', String(STATE.instructionsOpen));
    DOM.instructionsToggle.setAttribute('aria-label', STATE.instructionsOpen ? 'Collapse instructions' : 'Expand instructions');
  });
})();

/* =============================================================
   17. THREE.JS SCENE — INITIALISATION
   Full 3D AR scene with:
   - Floating cubes with glow materials
   - Ambient + point lighting
   - Auto-orbit camera
   - Raycasting hover / click
   - DOM label overlays
============================================================= */

/**
 * Initialise the Three.js renderer, scene, camera, and lighting.
 * Called once when the user first presses Start Demo.
 */
function initThreeScene() {
  if (!THREE_AVAILABLE) {
    showToast('3D engine unavailable. Please enable WebGL.', 'warn');
    return false;
  }
  if (!DOM.xrContainer) return false;

  const container = DOM.xrContainer;
  const w = container.clientWidth  || 800;
  const h = container.clientHeight || 500;

  /* ── Renderer ─────────────────────────────────────────── */
  SCENE.renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: true,            // transparent background (webcam shows through)
    powerPreference: 'high-performance',
  });
  SCENE.renderer.setSize(w, h);
  SCENE.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  SCENE.renderer.shadowMap.enabled = true;
  SCENE.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  container.appendChild(SCENE.renderer.domElement);

  /* ── Scene ────────────────────────────────────────────── */
  SCENE.scene = new THREE.Scene();
  SCENE.scene.fog = new THREE.FogExp2(0x030810, 0.04);

  /* ── Camera ───────────────────────────────────────────── */
  SCENE.camera = new THREE.PerspectiveCamera(60, w / h, 0.1, 200);
  SCENE.camera.position.set(0, 2, 10);
  SCENE.camera.lookAt(0, 0, 0);

  /* ── Raycaster ────────────────────────────────────────── */
  SCENE.raycaster = new THREE.Raycaster();

  /* ── Clock ────────────────────────────────────────────── */
  SCENE.clock = new THREE.Clock();

  /* ── Lighting ─────────────────────────────────────────── */
  setupLights();

  /* ── Environment geometry ─────────────────────────────── */
  setupEnvironment();

  /* ── Cubes ────────────────────────────────────────────── */
  rebuildCubes();

  /* ── Resize handler ───────────────────────────────────── */
  const onResize = debounce(() => {
    if (!SCENE.renderer || !SCENE.camera) return;
    const cw = container.clientWidth;
    const ch = container.clientHeight;
    SCENE.renderer.setSize(cw, ch);
    SCENE.camera.aspect = cw / ch;
    SCENE.camera.updateProjectionMatrix();
  }, 200);
  window.addEventListener('resize', onResize);

  /* ── Pointer / touch interaction ──────────────────────── */
  setupPointerInteraction(container);

  /* ── Device orientation ───────────────────────────────── */
  setupDeviceOrientation();

  return true;
}

/* =============================================================
   18. LIGHTING SETUP
============================================================= */
function setupLights() {
  const s = SCENE.scene;

  // Ambient — dim fill light
  const ambient = new THREE.AmbientLight(0x0a1520, 0.6);
  s.add(ambient);

  // Main key light (slightly warm)
  const keyLight = new THREE.DirectionalLight(0xffeedd, 0.8);
  keyLight.position.set(5, 8, 6);
  keyLight.castShadow = true;
  keyLight.shadow.mapSize.set(1024, 1024);
  s.add(keyLight);

  // Rim / accent light (tinted to palette)
  const rimLight = new THREE.PointLight(PALETTE_COLORS[STATE.palette], 2, 20);
  rimLight.position.set(-6, 4, -4);
  rimLight.name = 'rimLight';
  s.add(rimLight);

  // Fill light (opposite side)
  const fillLight = new THREE.PointLight(0x1a2a40, 1, 30);
  fillLight.position.set(8, -3, 8);
  s.add(fillLight);

  // Floor bounce light
  const bounceLight = new THREE.HemisphereLight(0x0b1a2e, 0x050a14, 0.4);
  s.add(bounceLight);
}

/* =============================================================
   19. ENVIRONMENT GEOMETRY
   A subtle grid floor + particle field for atmosphere.
============================================================= */
function setupEnvironment() {
  const s = SCENE.scene;

  /* Grid floor */
  const gridHelper = new THREE.GridHelper(40, 40, 0x0a1f32, 0x0a1f32);
  gridHelper.position.y = -3.5;
  s.add(gridHelper);

  /* Particle cloud */
  const particleCount = 300;
  const posArray = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount * 3; i++) {
    posArray[i] = (Math.random() - 0.5) * 30;
  }
  const pGeo = new THREE.BufferGeometry();
  pGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));

  const pMat = new THREE.PointsMaterial({
    color:       PALETTE_COLORS[STATE.palette],
    size:        0.06,
    transparent: true,
    opacity:     0.35,
    sizeAttenuation: true,
    name: 'particleMat',
  });
  pMat.name = 'particleMat';

  const particles = new THREE.Points(pGeo, pMat);
  particles.name = 'particleCloud';
  s.add(particles);

  /* Central glowing sphere (anchor orb) */
  const orbGeo = new THREE.SphereGeometry(0.35, 32, 32);
  const orbMat = new THREE.MeshStandardMaterial({
    color:       PALETTE_COLORS[STATE.palette],
    emissive:    PALETTE_COLORS[STATE.palette],
    emissiveIntensity: 1.4,
    metalness:   0.2,
    roughness:   0.1,
    transparent: true,
    opacity:     0.85,
  });
  orbMat.name = 'orbMat';
  const centralOrb = new THREE.Mesh(orbGeo, orbMat);
  centralOrb.name = 'centralOrb';
  s.add(centralOrb);
}

/* =============================================================
   20. CUBE CREATION & MANAGEMENT
============================================================= */

/**
 * App names assigned to AR cubes as labels.
 */
const APP_NAMES = [
  'Navigation', 'Health', 'Messages', 'Translate',
  'Calendar', 'Music', 'Weather', 'Camera',
  'Notes', 'Settings', 'Maps', 'Timer',
  'Finance', 'Fitness', 'Social', 'AI',
  'Gallery', 'Docs', 'Search', 'Alarm',
];

/**
 * Destroy all existing cubes and rebuild based on STATE.
 * Called on init and when Apply Changes is clicked.
 */
function rebuildCubes() {
  if (!SCENE.scene) return;

  // Remove old cubes from scene and DOM labels
  SCENE.cubes.forEach(({ mesh, label }) => {
    SCENE.scene.remove(mesh);
    if (mesh.geometry) mesh.geometry.dispose();
    if (mesh.material) mesh.material.dispose();
    if (label && label.parentNode) label.parentNode.removeChild(label);
  });
  SCENE.cubes = [];

  const count      = Math.round(STATE.cubeCount);
  const radius     = STATE.spreadRadius;
  const accentHex  = PALETTE_COLORS[STATE.palette];

  for (let i = 0; i < count; i++) {
    const cube = createCube(i, count, radius, accentHex);
    SCENE.cubes.push(cube);
    SCENE.scene.add(cube.mesh);
  }

  // Update HUD
  if (DOM.hudCubeCount) DOM.hudCubeCount.textContent = count + ' objects';
}

/**
 * Build a single AR cube with geometry, material, label, and position.
 * @param {number} index      Index in the array
 * @param {number} total      Total cube count
 * @param {number} radius     Distribution radius
 * @param {number} accentHex  THREE hex colour for emissive
 * @returns {object}  { mesh, label, basePos, speed, index }
 */
function createCube(index, total, radius, accentHex) {

  // Slightly varied sizes for visual interest
  const size = randFloat(0.5, 1.0);

  const geo = new THREE.BoxGeometry(size, size, size);

  // Unique colour per cube — hue-shifted from accent
  const hue  = (index / total) * 360;
  const col  = new THREE.Color().setHSL(hue / 360, 0.8, 0.55);

  const mat = new THREE.MeshStandardMaterial({
    color:             col,
    emissive:          col,
    emissiveIntensity: 0.3 + STATE.glowIntensity * 0.7,
    metalness:         0.6,
    roughness:         0.25,
    transparent:       true,
    opacity:           0.88,
    wireframe:         DOM.toggleWireframe?.checked || false,
  });

  const mesh = new THREE.Mesh(geo, mat);

  // Spherical distribution around origin
  const theta = (index / total) * Math.PI * 2;
  const phi   = randFloat(0.2, 0.85) * Math.PI;
  const r     = radius * randFloat(0.7, 1.3);

  const bx = r * Math.sin(phi) * Math.cos(theta);
  const by = r * Math.cos(phi) * randFloat(-0.6, 0.8);
  const bz = r * Math.sin(phi) * Math.sin(theta);

  mesh.position.set(bx, by, bz);
  mesh.castShadow    = true;
  mesh.receiveShadow = true;
  mesh.userData      = { index, appName: APP_NAMES[index % APP_NAMES.length], isARCube: true };

  // Per-cube rotation speed (randomised)
  const speed = {
    x: randFloat(-1, 1),
    y: randFloat(-1, 1),
    z: randFloat(-1, 1),
  };

  // DOM label overlay
  const label = createCubeLabel(APP_NAMES[index % APP_NAMES.length]);

  return {
    mesh,
    label,
    basePos: { x: bx, y: by, z: bz },
    speed,
    index,
    floatOffset: Math.random() * Math.PI * 2,  // stagger floating motion
  };
}

/**
 * Create a DOM overlay label for an AR cube.
 * @param {string} name  App name
 * @returns {HTMLElement}
 */
function createCubeLabel(name) {
  const el = document.createElement('div');
  el.className = 'ar-label';
  el.textContent = name;
  el.style.display = DOM.toggleLabels?.checked !== false ? 'block' : 'none';
  DOM.arViewport?.appendChild(el);
  return el;
}

/* =============================================================
   21. LIVE SCENE UPDATES (from sliders)
   Called in real-time as the user drags sliders.
============================================================= */

/**
 * Apply a single property change to the live scene.
 * @param {string} key    STATE property name
 * @param {number} value  New value
 */
function liveUpdateScene(key, value) {
  if (!STATE.demoActive) return;

  switch (key) {
    case 'glowIntensity': {
      // Update all cube emissive intensities
      SCENE.cubes.forEach(({ mesh }) => {
        if (mesh?.material) {
          mesh.material.emissiveIntensity = 0.3 + value * 0.007;
        }
      });
      // Update rim light intensity
      const rimLight = SCENE.scene?.getObjectByName('rimLight');
      if (rimLight) rimLight.intensity = 1 + value * 0.03;
      break;
    }
    // Cube count and radius require a full rebuild (applied on button click)
    default:
      break;
  }
}

/**
 * Update all cube and particle colours to match the current palette.
 */
function updateCubePalette() {
  const accentHex = PALETTE_COLORS[STATE.palette];

  // Rim light
  const rimLight = SCENE.scene?.getObjectByName('rimLight');
  if (rimLight) rimLight.color.setHex(accentHex);

  // Central orb
  const orbMat = SCENE.scene?.getObjectByName('centralOrb')?.material;
  if (orbMat) { orbMat.color.setHex(accentHex); orbMat.emissive.setHex(accentHex); }

  // Particle cloud
  const pCloud = SCENE.scene?.getObjectByName('particleCloud');
  if (pCloud?.material) pCloud.material.color.setHex(accentHex);
}

/* =============================================================
   22. POINTER / RAYCASTING INTERACTION
============================================================= */

/**
 * Wire up mouse / touch events for hover and click detection.
 * @param {HTMLElement} container
 */
function setupPointerInteraction(container) {

  // Track normalised device coordinates
  const updatePointer = (clientX, clientY) => {
    const rect = container.getBoundingClientRect();
    SCENE.pointer.x = ((clientX - rect.left) / rect.width)  *  2 - 1;
    SCENE.pointer.y = ((clientY - rect.top)  / rect.height) * -2 + 1;
  };

  // Mouse move
  container.addEventListener('mousemove', (e) => {
    updatePointer(e.clientX, e.clientY);
    STATE.mouseX = e.clientX;
    STATE.mouseY = e.clientY;
  }, { passive: true });

  // Touch move
  container.addEventListener('touchmove', (e) => {
    if (e.touches.length > 0) {
      updatePointer(e.touches[0].clientX, e.touches[0].clientY);
    }
  }, { passive: true });

  // Click / tap — select cube
  container.addEventListener('click', () => {
    if (!SCENE.hoveredCube) return;
    onCubeClick(SCENE.hoveredCube);
  });
}

/**
 * Handle a click on a specific cube.
 * @param {object} cubeData  Entry from SCENE.cubes
 */
function onCubeClick(cubeData) {
  // Deselect previous
  if (STATE.selectedCube && STATE.selectedCube !== cubeData) {
    STATE.selectedCube.mesh.scale.set(1, 1, 1);
  }
  STATE.selectedCube = cubeData;

  // Scale up selected cube
  cubeData.mesh.scale.set(1.4, 1.4, 1.4);

  // Show toast with app name
  showToast(`Selected: ${cubeData.mesh.userData.appName}`, 'info', 2000);
}

/* =============================================================
   23. DEVICE ORIENTATION (mobile tilt)
============================================================= */
function setupDeviceOrientation() {
  if (!window.DeviceOrientationEvent) return;

  window.addEventListener('deviceorientation', (e) => {
    STATE.deviceBeta  = e.beta  || 0;   // front-back tilt
    STATE.deviceGamma = e.gamma || 0;   // left-right tilt
  }, { passive: true });
}

/* =============================================================
   24. RAYCASTING — per-frame hover detection
============================================================= */
function performRaycast() {
  if (!SCENE.raycaster || !SCENE.camera || !SCENE.scene) return;

  SCENE.raycaster.setFromCamera(SCENE.pointer, SCENE.camera);

  const meshes = SCENE.cubes.map(c => c.mesh);
  const intersects = SCENE.raycaster.intersectObjects(meshes);

  if (intersects.length > 0) {
    const hitMesh   = intersects[0].object;
    const cubeData  = SCENE.cubes.find(c => c.mesh === hitMesh);

    if (cubeData !== SCENE.hoveredCube) {
      // Un-hover previous
      if (SCENE.hoveredCube) onCubeHoverEnd(SCENE.hoveredCube);
      // Hover new
      SCENE.hoveredCube = cubeData;
      onCubeHoverStart(cubeData);
    }
  } else {
    if (SCENE.hoveredCube) {
      onCubeHoverEnd(SCENE.hoveredCube);
      SCENE.hoveredCube = null;
    }
  }
}

function onCubeHoverStart(cubeData) {
  // Boost emissive
  if (cubeData.mesh?.material) {
    cubeData.mesh.material.emissiveIntensity = 1.8;
  }
  // Highlight label
  if (cubeData.label) cubeData.label.classList.add('hovered');
  // Change cursor
  if (DOM.arViewport) DOM.arViewport.style.cursor = 'pointer';
}

function onCubeHoverEnd(cubeData) {
  if (cubeData.mesh?.material) {
    cubeData.mesh.material.emissiveIntensity = 0.3 + STATE.glowIntensity * 0.007;
  }
  if (cubeData.label) cubeData.label.classList.remove('hovered');
  if (STATE.selectedCube !== cubeData && DOM.arViewport) {
    DOM.arViewport.style.cursor = 'crosshair';
  }
}

/* =============================================================
   25. LABEL OVERLAY POSITIONING
   Project 3D cube positions to 2D screen space for DOM labels.
============================================================= */
function updateLabelPositions() {
  if (!SCENE.camera || !SCENE.renderer || !DOM.arViewport) return;

  const container    = DOM.arViewport;
  const canvasWidth  = SCENE.renderer.domElement.clientWidth;
  const canvasHeight = SCENE.renderer.domElement.clientHeight;

  SCENE.cubes.forEach(({ mesh, label }) => {
    if (!label || label.style.display === 'none') return;

    // Get world position of cube
    const pos = new THREE.Vector3();
    mesh.getWorldPosition(pos);
    pos.y += (mesh.geometry.parameters.height || 0.75);  // offset above cube

    // Project to normalised device coordinates
    pos.project(SCENE.camera);

    // Convert to CSS pixels
    const x = ( pos.x *  0.5 + 0.5) * canvasWidth;
    const y = (-pos.y *  0.5 + 0.5) * canvasHeight;

    // Only show if in front of camera
    if (pos.z < 1) {
      label.style.opacity  = '1';
      label.style.left     = x + 'px';
      label.style.top      = y + 'px';
    } else {
      label.style.opacity  = '0';
    }
  });
}

/* =============================================================
   26. FPS COUNTER
============================================================= */
function updateFps(now) {
  STATE.frameCount++;
  if (now - STATE.lastFpsTime >= 1000) {
    STATE.fps           = STATE.frameCount;
    STATE.frameCount    = 0;
    STATE.lastFpsTime   = now;
    if (DOM.hudFps) DOM.hudFps.textContent = STATE.fps + ' fps';
  }
}

/* =============================================================
   27. MAIN RENDER / ANIMATION LOOP
============================================================= */
function animateScene() {
  SCENE.animId = requestAnimationFrame(animateScene);
  if (!SCENE.renderer || !SCENE.scene || !SCENE.camera) return;

  const delta = SCENE.clock.getDelta();
  const elapsed = SCENE.clock.getElapsedTime();
  const now = performance.now();

  // FPS tracking
  updateFps(now);

  // ── Auto-orbit camera ───────────────────────────────────
  if (DOM.toggleOrbit?.checked !== false) {
    SCENE.orbitAngle += delta * 0.15;
    const dist = 10;
    SCENE.camera.position.x = Math.sin(SCENE.orbitAngle) * dist;
    SCENE.camera.position.z = Math.cos(SCENE.orbitAngle) * dist;

    // Device tilt adds subtle offset
    SCENE.camera.position.y = 2 + STATE.deviceBeta  * 0.04;
    SCENE.camera.position.x += STATE.deviceGamma * 0.04;

    SCENE.camera.lookAt(0, 0, 0);
  }

  // ── Central orb pulse ──────────────────────────────────
  const orb = SCENE.scene.getObjectByName('centralOrb');
  if (orb) {
    orb.rotation.y += delta * 0.8;
    orb.scale.setScalar(1 + Math.sin(elapsed * 2) * 0.06);
  }

  // ── Particle cloud drift ───────────────────────────────
  const pCloud = SCENE.scene.getObjectByName('particleCloud');
  if (pCloud) pCloud.rotation.y += delta * 0.04;

  // ── Cube animation ─────────────────────────────────────
  const speedMult = (STATE.rotationSpeed / 10) * 0.8;

  SCENE.cubes.forEach(({ mesh, speed, basePos, floatOffset }, i) => {
    // Rotate
    mesh.rotation.x += delta * speed.x * speedMult;
    mesh.rotation.y += delta * speed.y * speedMult;
    mesh.rotation.z += delta * speed.z * speedMult * 0.3;

    // Float up/down
    const floatY = Math.sin(elapsed * 0.6 + floatOffset) * 0.3;
    mesh.position.y = basePos.y + floatY;

    // Gentle sway
    mesh.position.x = basePos.x + Math.sin(elapsed * 0.4 + floatOffset * 1.3) * 0.15;

    // If selected, pulse scale
    if (STATE.selectedCube?.mesh === mesh) {
      const pulse = 1.3 + Math.sin(elapsed * 4) * 0.07;
      mesh.scale.setScalar(pulse);
    }
  });

  // ── Raycasting (every 2nd frame for perf) ─────────────
  if (STATE.frameCount % 2 === 0) performRaycast();

  // ── Label positions ───────────────────────────────────
  updateLabelPositions();

  // ── HUD coords ───────────────────────────────────────
  if (DOM.hudCoords) {
    const p = SCENE.camera.position;
    DOM.hudCoords.textContent =
      `x:${p.x.toFixed(1)} y:${p.y.toFixed(1)} z:${p.z.toFixed(1)}`;
  }

  // ── Render ────────────────────────────────────────────
  SCENE.renderer.render(SCENE.scene, SCENE.camera);
}

/* =============================================================
   28. DEMO LIFECYCLE — START
============================================================= */
function startDemo() {
  if (STATE.demoActive) return;

  // First time: initialise the Three.js scene
  if (!STATE.demoInitialised) {
    const ok = initThreeScene();
    if (!ok) return;
    STATE.demoInitialised = true;
  }

  STATE.demoActive = true;

  // Hide idle overlay
  if (DOM.demoIdle) DOM.demoIdle.classList.add('hidden');

  // Mark viewport as active
  if (DOM.arViewport) {
    DOM.arViewport.classList.add('demo-active');
    DOM.arViewport.style.cursor = 'crosshair';
  }

  // Update HUD status
  if (DOM.hudStatus) DOM.hudStatus.textContent = 'Active';

  // Start render loop
  if (SCENE.clock) SCENE.clock.start();
  animateScene();

  showToast('AR Scene activated — 3D demo running', 'success');
}

/* =============================================================
   29. DEMO LIFECYCLE — RESET
============================================================= */
function resetScene() {
  // Stop animation loop
  if (SCENE.animId) {
    cancelAnimationFrame(SCENE.animId);
    SCENE.animId = null;
  }

  // Destroy renderer
  if (SCENE.renderer) {
    SCENE.renderer.dispose();
    const canvas = SCENE.renderer.domElement;
    if (canvas?.parentNode) canvas.parentNode.removeChild(canvas);
    SCENE.renderer = null;
  }

  // Remove label overlays
  SCENE.cubes.forEach(({ label }) => {
    if (label?.parentNode) label.parentNode.removeChild(label);
  });
  SCENE.cubes = [];

  // Reset scene objects
  SCENE.scene    = null;
  SCENE.camera   = null;

  STATE.demoActive      = false;
  STATE.demoInitialised = false;
  SCENE.orbitAngle      = 0;

  // Show idle overlay
  if (DOM.demoIdle) DOM.demoIdle.classList.remove('hidden');
  if (DOM.arViewport) DOM.arViewport.classList.remove('demo-active');
  if (DOM.hudStatus)  DOM.hudStatus.textContent  = 'Inactive';
  if (DOM.hudFps)     DOM.hudFps.textContent     = '-- fps';
  if (DOM.hudCoords)  DOM.hudCoords.textContent  = 'x:0 y:0 z:0';

  showToast('Scene reset to defaults', 'info', 2000);
}

/* =============================================================
   30. APPLY SCENE SETTINGS (sidebar "Apply Changes")
============================================================= */
function applySceneSettings() {
  if (!STATE.demoActive) {
    showToast('Start the demo first to apply changes', 'warn', 2000);
    return;
  }

  // Read latest slider values into STATE
  STATE.cubeCount     = DOM.sliderCubeCount ? parseInt(DOM.sliderCubeCount.value) : STATE.cubeCount;
  STATE.rotationSpeed = DOM.sliderSpeed     ? parseFloat(DOM.sliderSpeed.value)   : STATE.rotationSpeed;
  STATE.glowIntensity = DOM.sliderGlow      ? parseFloat(DOM.sliderGlow.value)    : STATE.glowIntensity;
  STATE.spreadRadius  = DOM.sliderRadius    ? parseFloat(DOM.sliderRadius.value)  : STATE.spreadRadius;

  // Rebuild cube array
  rebuildCubes();

  showToast(`Scene updated — ${Math.round(STATE.cubeCount)} objects`, 'success', 2500);
}

/* =============================================================
   31. BUTTON EVENT BINDINGS
============================================================= */
(function bindButtons() {

  // Hero "Start Demo" button
  if (DOM.startDemoBtn) {
    DOM.startDemoBtn.addEventListener('click', () => {
      document.getElementById('demo')?.scrollIntoView({ behavior: 'smooth' });
      setTimeout(startDemo, 600);
    });
  }

  // Idle overlay "Start Demo" button
  if (DOM.startDemoBtn2) {
    DOM.startDemoBtn2.addEventListener('click', startDemo);
  }

  // Apply changes button
  if (DOM.applySceneBtn) {
    DOM.applySceneBtn.addEventListener('click', applySceneSettings);
  }

  // Reset scene button
  if (DOM.resetSceneBtn) {
    DOM.resetSceneBtn.addEventListener('click', resetScene);
  }

})();

/* =============================================================
   32. KEYBOARD SHORTCUTS
============================================================= */
document.addEventListener('keydown', (e) => {

  // Ignore when focused in input
  if (document.activeElement?.tagName === 'INPUT') return;

  switch (e.key) {
    case ' ':
      e.preventDefault();
      STATE.demoActive ? resetScene() : startDemo();
      break;
    case 'r':
    case 'R':
      if (STATE.demoActive) resetScene();
      break;
    case 'Escape':
      // Close mobile menu if open
      if (DOM.hamburgerBtn?.getAttribute('aria-expanded') === 'true') {
        DOM.hamburgerBtn.setAttribute('aria-expanded', 'false');
        DOM.mobileMenu?.classList.remove('open');
      }
      // Deselect cube
      if (STATE.selectedCube) {
        STATE.selectedCube.mesh.scale.set(1, 1, 1);
        STATE.selectedCube = null;
      }
      break;
  }
});

/* =============================================================
   33. PRELOAD CLASS REMOVAL
   Remove the 'preload' class after the page has painted so
   CSS transitions aren't suppressed by the transition-none rule.
============================================================= */
window.addEventListener('load', () => {
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      DOM.body.classList.remove('preload');
    });
  });
});

/* =============================================================
   34. THREE.JS NOT AVAILABLE — FALLBACK DEMO
   If Three.js fails to load (network issue etc.), create a
   CSS-only fallback so the demo section isn't just empty.
============================================================= */
(function maybeActivateFallback() {
  if (THREE_AVAILABLE) return;

  console.info('[CRSPY] Three.js not available. Activating CSS fallback demo.');

  // The idle state will still be there; we patch the start button
  // to show a "canvas-less" demo using CSS animations only.
  const injectFallback = () => {
    if (!DOM.xrContainer) return;

    DOM.xrContainer.innerHTML = `
      <div style="
        position:absolute;inset:0;display:flex;align-items:center;
        justify-content:center;gap:24px;flex-wrap:wrap;
        background:radial-gradient(ellipse 80% 60% at 50% 50%,
          rgba(0,245,255,.05) 0%,transparent 70%);
        padding:32px;
      ">
        ${Array.from({length: 6}).map((_, i) => `
          <div style="
            width:80px;height:80px;
            background:rgba(0,245,255,.07);
            border:1px solid rgba(0,245,255,.25);
            border-radius:12px;
            display:flex;align-items:center;justify-content:center;
            font-family:'Syne',sans-serif;font-size:11px;font-weight:700;
            letter-spacing:.1em;text-transform:uppercase;
            color:rgba(0,245,255,.7);
            box-shadow:0 0 20px rgba(0,245,255,.08);
            animation:cubeFloat ${4.5 + i * 0.4}s ${-i * 0.6}s ease-in-out infinite;
          ">${APP_NAMES[i]}</div>
        `).join('')}
      </div>`;
  };

  // Override start buttons
  [DOM.startDemoBtn, DOM.startDemoBtn2].forEach(btn => {
    if (!btn) return;
    btn.addEventListener('click', () => {
      if (DOM.demoIdle) DOM.demoIdle.classList.add('hidden');
      if (DOM.arViewport) DOM.arViewport.classList.add('demo-active');
      if (DOM.hudStatus)  DOM.hudStatus.textContent = 'CSS Fallback';
      injectFallback();
      showToast('Running in CSS fallback mode (WebGL unavailable)', 'warn', 5000);
    }, { once: true });
  });
})();

/* =============================================================
   35. APP CUBE HOVER SOUND STUB
   Placeholder for Web Audio API click / hover feedback.
   Expand this into a full AudioContext implementation to add
   spatial AR-style UI sounds.
============================================================= */
(function initAudioStub() {
  // Create audio context lazily on first user gesture
  let audioCtx = null;

  const getCtx = () => {
    if (!audioCtx) {
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      } catch (_) { /* not available */ }
    }
    return audioCtx;
  };

  /**
   * Play a short synthetic click tone.
   * @param {number} freq   Frequency in Hz
   * @param {number} dur    Duration in seconds
   */
  const playTone = (freq = 880, dur = 0.06) => { // eslint-disable-line no-unused-vars
    const ctx = getCtx();
    if (!ctx) return;
    const osc  = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = freq;
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + dur);
  };

  // Wire subtle hover tones to app cubes
  document.querySelectorAll('.app-cube').forEach(cube => {
    cube.addEventListener('mouseenter', () => playTone(1200, 0.04));
    cube.addEventListener('click',      () => playTone(880,  0.08));
  });
})();

/* =============================================================
   36. INTERSECTION OBSERVER — lazy scroll-reveal
============================================================= */
(function initScrollReveal() {
  if (!window.IntersectionObserver) {
    // Fallback: show all
    document.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target); // observe once
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
})();

/* =============================================================
   37. STATS COUNTER ANIMATION
   Animate the hero stat numbers from 0 to their final value.
============================================================= */
(function animateCounters() {
  const stats = document.querySelectorAll('.stat-val');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const raw = el.textContent.trim();

      // Extract numeric part and suffix
      const match = raw.match(/^([\d.]+)(.*)$/);
      if (!match) return;

      const target = parseFloat(match[1]);
      const suffix = match[2] || '';
      const isFloat = raw.includes('.');

      let start = 0;
      const duration = 1200;
      const startTime = performance.now();

      const tick = (now) => {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased    = 1 - Math.pow(1 - progress, 3); // cubic ease-out
        const value    = start + (target - start) * eased;
        el.textContent = (isFloat ? value.toFixed(1) : Math.round(value)) + suffix;
        if (progress < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  stats.forEach(el => observer.observe(el));
})();

/* =============================================================
   38. SMOOTH SCROLL FOR ANCHOR LINKS
   Handles in-page navigation anchors with offset for fixed header.
============================================================= */
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', (e) => {
    const hash    = link.getAttribute('href');
    if (hash === '#') return;
    const target  = document.querySelector(hash);
    if (!target) return;

    e.preventDefault();
    const headerH = DOM.header?.offsetHeight || 80;
    const top     = target.getBoundingClientRect().top + window.scrollY - headerH - 16;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

/* =============================================================
   39. RESIZE HANDLER — responsive adjustments
============================================================= */
window.addEventListener('resize', debounce(() => {
  // If demo is running, Three.js handles its own resize via event.
  // We just need to update any layout-dependent CSS values here.
  onScroll();
}, 200));

/* =============================================================
   40. INITIAL TOAST (welcome)
============================================================= */
window.addEventListener('load', () => {
  setTimeout(() => {
    showToast('Welcome to CRSPY — press Space or click Start Demo ▶', 'info', 5000);
  }, 1800);
});

/* =============================================================
   41. EXPORT (for potential module use)
============================================================= */
// Expose key functions to global scope for console testing / expansion
window.CRSPY = {
  startDemo,
  resetScene,
  applySceneSettings,
  showToast,
  STATE,
  SCENE,
};
